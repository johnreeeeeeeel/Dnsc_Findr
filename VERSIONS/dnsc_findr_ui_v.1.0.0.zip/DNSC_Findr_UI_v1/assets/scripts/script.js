const userForm = document.getElementById("user-login-form");
const adminForm = document.getElementById("admin-login-form");
const signupForm = document.getElementById("user-signup-form");

document.getElementById("show-signup").addEventListener("click", (e) => {
  e.preventDefault();
  userForm.style.display = "none";
  adminForm.style.display = "none";
  signupForm.style.display = "flex";
});

document.getElementById("back-to-login").addEventListener("click", (e) => {
  e.preventDefault();
  signupForm.style.display = "none";
  userForm.style.display = "block";
});

document.getElementById("switch-to-admin").addEventListener("click", (e) => {
  e.preventDefault();
  userForm.style.display = "none";
  signupForm.style.display = "none";
  adminForm.style.display = "block";
});

document.getElementById("switch-to-user").addEventListener("click", (e) => {
  e.preventDefault();
  adminForm.style.display = "none";
  signupForm.style.display = "none";
  userForm.style.display = "block";
});

// SHOW HIDE PASSWORD

function togglePassword(formId) {
    const password = document.querySelector(`#${formId} input[type="password"]`);
    const checkbox = document.querySelector(`#${formId} input[type="checkbox"]`);
    checkbox.addEventListener("change", function () {
        password.type = this.checked ? "text" : "password";
    });
}

togglePassword("user-login-form");
togglePassword("admin-login-form");

// MESSAGE FUNCTION

function showConversation() {
    document.getElementById("contactList").style.display = "none";
    document.getElementById("conversationView").style.display = "flex";
}

function backToContacts() {
    document.getElementById("conversationView").style.display = "none";
    document.getElementById("contactList").style.display = "block";
}

function showProfile() {
    document.getElementById("contactList").style.display = "none";
    document.getElementById("conversationView").style.display = "none";
    document.getElementById("viewProfile").style.display = "flex";
}

function backToConversation() {
    document.getElementById("viewProfile").style.display = "none";
    document.getElementById("conversationView").style.display = "flex";
}

function desktopToggleFilters() {
    const filterPanel = document.getElementById("desktop-filter-panel");
    if (filterPanel.style.display === "none") {
        filterPanel.style.display = "flex";
    } else {
        filterPanel.style.display = "none";
    }
}

function offcanvasToggleFilters() {
    const filterPanel = document.getElementById("offcanvas-filter-panel");
    if (filterPanel.style.display === "none") {
        filterPanel.style.display = "flex";
    } else {
        filterPanel.style.display = "none";
    }
}

// PROFILE FUNCTION

function showEditProfileContainer() {
    document.getElementById("editProfileContainer").style.display = "flex";
    document.getElementById("profileCard").style.display = "none";
}

function showprofileCard() {
    document.getElementById("editProfileContainer").style.display = "none";
    document.getElementById("profileCard").style.display = "flex";
}